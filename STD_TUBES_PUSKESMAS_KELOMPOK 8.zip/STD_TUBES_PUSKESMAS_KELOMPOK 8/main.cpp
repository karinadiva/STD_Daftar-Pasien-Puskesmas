#include "puskesmas.h"
#include <iostream>

using namespace std;

int main()
{
    "Hello World!";

    return 0;
}
