#ifndef PUSKESMAS_H_INCLUDED
#define PUSKESMAS_H_INCLUDED

#include <iostream>

using namespace std;

#define firstP(P) ((P).firstP)
#define firstC(C) ((C).firstC)
#define infoP(P) (P) -> infoP
#define infoC(C) (C) -> infoC
#define nextP(P) (P) -> nextP
#define nextC(C) (C) -> nextC
#define nil NULL

typedef struct poliklinik infotype;
typedef struct pasien infotype;
typedef struct elmKlinik *adrP;
typedef struct elmPasien *adrC;


struct poliklinik{
    string jenis;
};

struct pasien{
    string nama, keluhan;
    int umur, noPasien, nik;
};

struct elmKlinik{
    poliklinik infoP;
    adrP nextP;
};

struct elmPasien{
    pasien infoC;
    adrC nextC;
};

struct listPoliklinik{
    adrP firstP;
};
struct listPasien{
    adrC firstC;
};

void createListK(listPoliklinik &K);
adrP createElmK(infotype x);
void insertLastK(listPoliklinik &K, adrP P);
void deleteFirstK(listPoliklinik &K, adrP P);
void deleteLastK(listPoliklinik &K, adrP P);
adrP findK(listPoliklinik K, infotype x);
void showK(listPoliklinik K);

void createListP(listPasien &P);
adrP createElmP(infotype y);
void insertLastP(listPasien &P);
void deleteFirstP(listPasien &P, adrC C);
void deleteLastP(listPasien &P, adrC C);
adrP findP(listPasien P, infotype x);
void showP(listPasien P);




#endif // PUSKESMAS_H_INCLUDED
