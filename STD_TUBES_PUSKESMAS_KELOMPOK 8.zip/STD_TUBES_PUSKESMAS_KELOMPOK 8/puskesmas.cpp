#include "puskesmas.h"

void createListK(listPoliklinik &K){
    firstP(K) = nil;
}
adrP createElmK(infotype x){
    adrP p = new elmKlinik;
    infoP(p) = x;
    next(p) = nil;
    return p;
}
void insertLastK(listPoliklinik &K, adrP P){
    adrP Q = firstP(K);
    while(nextP(Q) != nil){
        Q = nextP(Q);
    }
    next(Q) = P;
}
void deleteFirstK(listPoliklinik &K, adrP &P){
    P = firstP(K);
    if (P != nil){
        firstP(K) = nextP(K);
        nextP = nil;
    }
}
adrP findElmK(listPoliklinik K, string x){
    adrP P = firstP(K);
    while(P != nil){
        if(infoP(P) == x){
            return P;
        }
        P = nextP(P);
    }
    return nil;
}
void showK(listPoliklinik K){
    int i = 1;
    adrP P = firstP(K);
    cout << "Daftar Poliklinik" << endl;
    while (P != nil){
        cout << i << infoP(P).jenis << endl;
        P = nextP(P);
        i++;
    }
    cout << endl << endl;
}

void connect
